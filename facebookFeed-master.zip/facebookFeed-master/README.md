Facebook Feed Plugin
===============

Plugin for adding a Facebook feed to OJS/OMP sidebar

## Usage

Install by copying this plugin to **plugins/generic** folder and activate this plugin form **Settings > Website > Plugins**.

Once activated, edit the plugin settings and add your Facebook page url.

Make sure that the Facebook Feed block is activated in **Settings > Website > Appearance**.

## License
This plugin is licensed under the GNU General Public License v2.

## Compatibility
This plugin is compatible with OJS 3.1+ and OMP 3.1+
